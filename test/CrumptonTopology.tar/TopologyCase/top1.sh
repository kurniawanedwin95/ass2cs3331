 #!/bin/bash
xterm -e "bash -c \"java Lsr G 2000 configG.txt; exec bash\"" &
xterm -e "bash -c \"java Lsr H 2001 configH.txt; exec bash\"" &
xterm -e "bash -c \"java Lsr I 2002 configI.txt; exec bash\"" &
xterm -e "bash -c \"java Lsr J 2003 configJ.txt; exec bash\"" &
xterm -e "bash -c \"java Lsr K 2004 configK.txt; exec bash\"" &
xterm -e "bash -c \"java Lsr L 2005 configL.txt; exec bash\"" &
xterm -e "bash -c \"java Lsr M 2006 configM.txt; exec bash\"" &
xterm -e "bash -c \"java Lsr N 2007 configN.txt; exec bash\"" &
xterm -e "bash -c \"java Lsr O 2008 configO.txt; exec bash\"" &
xterm -e "bash -c \"java Lsr P 2009 configP.txt; exec bash\"" &
